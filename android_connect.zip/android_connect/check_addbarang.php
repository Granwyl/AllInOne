<?php
    include "conn.php";
    //$idbarang=escape_get("id_barang");
    $namabarang=escape_get("barang");
    $idpenjual=escape_get("user");
    $jenisbarang=escape_get("jenis");
    $harga=escape_get("harga");
    $stok=escape_get("stok");


    //$result=["result"=>"ok"];

    $result["hasil"]="ok";
   
        $q="INSERT INTO barang ( nama, id_penjual, jenis_barang, harga, stok) VALUES ( '$namabarang', '$idpenjual', '$jenisbarang', '$harga', '$stok')";
        //echo $q;
        mysqli_query($link,$q);
   

    echo json_encode($result);
    //if($saved) header("Location: checklogin.php");
    
?>