<?php
    include "conn.php";
    $result=[];
    $arr=[];
    $q="SELECT * FROM barang";
    $res=mysqli_query($link,$q);
    while ($row=mysqli_fetch_assoc($res))
    {
        $arr[]=$row;
    }
    $result["data"]=$arr;
    echo json_encode($result);
?>