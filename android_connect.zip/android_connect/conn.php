<?php
    $host   = 'localhost';
    $user   = 'root';
    $password = '';
    $database = 'asd';

    $link = mysqli_connect($host, $user, $password);
    $db  = mysqli_select_db($link, $database) or die(mysqli_error($link));


    function escape_get($idx)
    {
        global $link;
        if (isset($_GET[$idx]))
        {
            return mysqli_real_escape_string($link,$_GET[$idx]);
        }
        else {
            return "";
        }
    }

    function escape_post($idx)
    {
        global $link;
        if (isset($_POST[$idx]))
        {
            return mysqli_real_escape_string($link,$_POST[$idx]);
        }
        else {
            return "";
        }
    }
?>