<?php
    include "conn.php";
    $username=escape_get("username");
    $email=escape_get("email");
    $pass=escape_get("password");
    $typ=escape_get("type");
    $phone=escape_get("phone");
    $saldo=0;//filter_input("saldo");


    $result=["result"=>"ok"];

    $result["hasil"]="ok";
    $q="SELECT * FROM user WHERE username='$username'";
    $res=mysqli_query($link,$q);
    if ($row=mysqli_fetch_assoc($res))
    {
        $result["hasil"]="no";
    }
    else {
        $q="INSERT INTO user (username, email, password, type, phone, saldo) VALUES ('$username', '$email', '$pass', '$typ', '$phone', '$saldo')";
        //echo $q;
        mysqli_query($link,$q);
    }
    
    
    //$stmt = $db->prepare($q);


    echo json_encode($result);
    //if($saved) header("Location: checklogin.php");
    
?>