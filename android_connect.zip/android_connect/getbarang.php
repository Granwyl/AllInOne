<?php
    include "conn.php";
    //$username=escape_get("username");
    //$password=escape_get("password");


    //$result=["result"=>"no"];

    $arr=[];
    $q="SELECT * FROM barang";
    $res=mysqli_query($link,$q);

    while ($row=mysqli_fetch_assoc($res))
    {
        $arr[]=$row;
    }
    echo json_encode($arr);
?>