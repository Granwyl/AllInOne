<?php
    echo "Welcome, I am connecting Android to PHP, MySQL";
?>