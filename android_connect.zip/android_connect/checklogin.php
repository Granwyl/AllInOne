<?php
    include "conn.php";
    $username=escape_get("username");
    $password=escape_get("password");


    $result=["result"=>"no"];

    $q="SELECT * FROM user WHERE username='$username' AND password='$password'";
    $res=mysqli_query($link,$q);

    if ($row=mysqli_fetch_assoc($res))
    {
        $result["result"]="ok";
        $result["user"]=$row;
    }
    echo json_encode($result);
?>